# Testing procedures & benchmarking methodology

## A. Unit tests (no device)
`./gradlew :app:testDebugUnitTest` — covers frame statistics (avg, 1% low, drops), SurfaceFlinger parser, temperature slope, ceiling-reduction math, and the root tuner's refusal rules (overclock, out-of-table, hot device, shell-injection in governor names).

## B. On-device smoke tests (non-root)
1. Install, grant notifications, press **Start**.
2. CPU/GPU tab: policies should list; every unreadable value must show `N/A` with a reason (never `0`).
3. Overview: battery values should move when you plug/unplug the charger.
4. Thermal tab: confirm OS status and headroom populate. Set a USER threshold slightly below current battery temp → a warning appears with `USER-SET, unverified`.
5. Confirm the *Reference limit* is `UNKNOWN` for every class you haven't set.
6. Stop → service notification disappears.

## C. Cross-check against adb
Compare in-app readings with `docs/ADB_COMMANDS.md` outputs taken at the same moment (±1 s). Any value shown as ACTUAL in the app must match adb within normal sampling error. Report mismatches.

## D. Benchmark methodology (to claim any improvement)
A change counts as an improvement only if it passes all of these:
1. **Same scenario**: same BGMI map/match type, same in-game replay or training-ground route, same settings, same time of day.
2. **Same start state**: battery 60–80 %, not charging (or always charging — pick one), screen brightness fixed, airplane/Wi-Fi state fixed, Game Assistant mode fixed, device idle ≥10 min so temperatures start within ~2 °C of each other (record start temps).
3. **Duration ≥ 15 min** per run (thermal steady state, not a burst).
4. **≥ 5 runs per configuration**, alternating A/B/A/B to cancel drift; discard none; report median and min/max.
5. **Metrics per run** (from `tools/analyze_frames.py` + telemetry.csv): average FPS, 1% low FPS, p99 frame time, jitter σ, drop %, in-target %, time to first throttle (thermal status ≥ 1), final CPU ceiling reduction, end battery temp, battery drain %.
6. **Decision rule**: B is better than A only if the median 1% low and in-target % improve and the 5-run ranges don't overlap (or a paired comparison is significant). Average FPS alone is not sufficient.
7. **Record** firmware build and kernel string (`meta.txt`). A change in OxygenOS version resets the baseline.

Candidate configurations to compare: (1) default; (2) Game Assistant performance mode; (3) 120 fps vs locked 90 fps; (4) one in-game preset lower; (5) root ceiling cap on prime cluster (optional); (6) with/without charging; (7) with/without case.

## E. Caveats
- FPS from SurfaceFlinger present times measures what the compositor presented; it is the right quantity for smoothness but can differ from the game's internal tick counter.
- A 165 Hz panel running a 120 fps game produces uneven presentation intervals unless the OS switches panel mode to a multiple; in-target % is therefore computed against a tolerance (≤ 1.25× target). Verify the active refresh rate: `adb shell dumpsys display | grep -i refresh`.
- The in-app performance score is a relative estimate for comparing runs, not a benchmark.
