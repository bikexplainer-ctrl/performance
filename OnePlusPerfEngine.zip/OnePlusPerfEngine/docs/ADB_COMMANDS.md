# ADB diagnostic commands (all read-only)

Enable Developer options → USB debugging, then `adb devices`.

## Identity & firmware
```
adb shell getprop ro.product.model
adb shell getprop ro.build.display.id
adb shell getprop ro.soc.model; adb shell getprop ro.soc.manufacturer
adb shell uname -a
adb shell getenforce
adb shell getprop ro.boot.verifiedbootstate; adb shell getprop ro.boot.flash.locked
```

## CPU
```
adb shell ls /sys/devices/system/cpu/cpufreq/
adb shell 'for p in /sys/devices/system/cpu/cpufreq/policy*; do echo $p; cat $p/related_cpus; for f in cpuinfo_min_freq cpuinfo_max_freq scaling_min_freq scaling_max_freq scaling_cur_freq scaling_governor scaling_available_governors scaling_available_frequencies; do printf "  %s: " $f; cat $p/$f 2>&1; done; done'
adb shell cat /proc/stat | head -n 12
adb shell cat /proc/cpuinfo | head -n 40
adb shell 'ls /sys/devices/system/cpu/cpu0/ | head -50; ls /sys/devices/system/cpu/ | grep -i core_ctl'
adb shell zcat /proc/config.gz | grep -E 'CPU_FREQ|SCHED|THERMAL|WALT|ENERGY'      # may be absent
```

## GPU (kgsl)
```
adb shell ls /sys/class/kgsl/kgsl-3d0/
adb shell 'cd /sys/class/kgsl/kgsl-3d0; for f in gpuclk max_gpuclk gpu_busy_percentage temp devfreq/cur_freq devfreq/min_freq devfreq/max_freq devfreq/available_frequencies; do printf "%s: " $f; cat $f 2>&1; done'
adb shell dumpsys SurfaceFlinger | grep -i -E 'GLES|renderer'
```

## Thermal
```
adb shell dumpsys thermalservice
adb shell 'for z in /sys/class/thermal/thermal_zone*; do echo "$(cat $z/type) $(cat $z/temp)"; done'
adb shell 'ls /sys/class/thermal/ | grep cooling; for c in /sys/class/thermal/cooling_device*; do echo "$(cat $c/type) cur=$(cat $c/cur_state) max=$(cat $c/max_state)"; done'
```

## Battery / power
```
adb shell dumpsys battery
adb shell cat /sys/class/power_supply/battery/{temp,voltage_now,current_now,charge_full,charge_full_design,cycle_count}
```

## Memory
```
adb shell cat /proc/meminfo | head -n 12
adb shell cat /proc/pressure/memory
adb shell dumpsys meminfo | head -n 40
```

## Game / frames (BGMI must be running in the foreground)
```
adb shell dumpsys SurfaceFlinger --list | grep -i pubg
adb shell "dumpsys SurfaceFlinger --latency 'SurfaceView[com.pubg.imobile/...]#0'"   # use the exact layer name from --list
adb shell dumpsys gfxinfo com.pubg.imobile framestats          # may be empty for GL/Vulkan game surfaces
adb shell cmd game list-configs com.pubg.imobile               # Game Mode config, if supported
adb shell top -b -n 1 -m 15 -o PID,%CPU,RES,ARGS
```

## Whole-run capture
```
tools/bench_capture.sh run1 900          # 15 minutes
python3 tools/analyze_frames.py bench/run1 --target 120
```
Please paste any output you want interpreted; some of these paths may not exist on OxygenOS 16 and that is useful information, not an error.

## Root (only if you have it) — read-only checks
```
adb shell su -c id
adb shell su -c 'test -w /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq && echo writable'
```
Root is obtained by your own means (e.g., Magisk after unlocking). Unlocking the bootloader wipes the device; verify the 15R procedure with OnePlus before attempting. This project does not include root or unlock tooling.
