#!/usr/bin/env bash
# Read-only benchmark capture over adb. Writes nothing to the phone's kernel interfaces.
# Usage: tools/bench_capture.sh <label> <seconds> [layer-substring, default com.pubg.imobile]
# Output: bench/<label>/{telemetry.csv,frames_raw.txt}. Then: python3 tools/analyze_frames.py bench/<label> --target 120
set -euo pipefail
LABEL="${1:?label}"; SECS="${2:?seconds}"; PKG="${3:-com.pubg.imobile}"
OUT="bench/$LABEL"; mkdir -p "$OUT"
sh() { adb shell "$@" | tr -d '\r'; }

LAYER="$(sh dumpsys SurfaceFlinger --list | grep "$PKG" | grep -m1 SurfaceView || true)"
[ -z "$LAYER" ] && LAYER="$(sh dumpsys SurfaceFlinger --list | grep -m1 "$PKG" || true)"
echo "layer: ${LAYER:-NOT FOUND (start the game first)}" | tee "$OUT/meta.txt"
{ echo "build: $(sh getprop ro.build.display.id)"; echo "kernel: $(sh uname -a)"; } >> "$OUT/meta.txt"

echo "ts,thermal_status,batt_temp_dC,batt_mV,batt_uA,pol_cur_khz(all policies),pol_max_khz(all policies)" > "$OUT/telemetry.csv"
: > "$OUT/frames_raw.txt"
END=$(( $(date +%s) + SECS ))
while [ "$(date +%s)" -lt "$END" ]; do
  T=$(date +%s)
  TS=$(sh dumpsys thermalservice | grep -m1 -o 'Thermal Status: [0-9]*' | grep -o '[0-9]*' || echo "")
  B=$(sh dumpsys battery); BT=$(echo "$B" | awk '/temperature/{print $2}'); BV=$(echo "$B" | awk '/voltage/{print $2}')
  BI=$(sh cat /sys/class/power_supply/battery/current_now 2>/dev/null || echo "")
  CUR=$(sh 'for p in /sys/devices/system/cpu/cpufreq/policy*; do printf "%s " $(cat $p/scaling_cur_freq 2>/dev/null); done')
  MAX=$(sh 'for p in /sys/devices/system/cpu/cpufreq/policy*; do printf "%s " $(cat $p/scaling_max_freq 2>/dev/null); done')
  echo "$T,$TS,$BT,$BV,$BI,\"$CUR\",\"$MAX\"" >> "$OUT/telemetry.csv"
  [ -n "$LAYER" ] && sh dumpsys SurfaceFlinger --latency "'$LAYER'" | sed "1!b" >> "$OUT/frames_raw.txt" || true
  sleep 1
done
echo "done -> $OUT"
