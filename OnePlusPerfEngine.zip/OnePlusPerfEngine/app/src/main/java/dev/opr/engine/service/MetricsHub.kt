package dev.opr.engine.service

import dev.opr.engine.data.SystemSnapshot
import dev.opr.engine.game.Bottleneck
import dev.opr.engine.game.FrameStats
import dev.opr.engine.thermal.Level
import dev.opr.engine.thermal.Warning
import kotlinx.coroutines.flow.MutableStateFlow

data class HubState(
    val running: Boolean = false,
    val snapshot: SystemSnapshot? = null,
    val warnings: List<Warning> = emptyList(),
    val level: Level = Level.GREEN,
    val series: Map<String, List<Float>> = emptyMap(),
    val frameStats: FrameStats? = null,
    val frameSource: String = "none",
    val bottleneck: Bottleneck? = null,
    val perfScore: Int? = null,
    val perfScoreBasis: String = "",
    val throttleTimeline: List<Int> = emptyList(),   // OS thermal status per second, newest last
    val sessionTag: String = "",
)

/** Process-wide state shared by the foreground service (writer) and Compose UI (reader). */
object MetricsHub {
    val state = MutableStateFlow(HubState())
}
