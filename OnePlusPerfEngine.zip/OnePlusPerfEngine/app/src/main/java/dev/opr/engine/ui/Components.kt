package dev.opr.engine.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import dev.opr.engine.data.*

@Composable
fun Panel(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().background(C.panel, RoundedCornerShape(14.dp)).border(1.dp, C.line, RoundedCornerShape(14.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) { Text(title.uppercase(), style = Label); content() }
}

/** Value with provenance tag: ACTUAL / ESTIMATE / N/A. Hover text (detail) is shown as small caption. */
@Composable
fun <T> ReadingRow(label: String, r: Reading<T>, fmt: (T) -> String = { it.toString() }) {
    val (txt, col) = when (r) {
        is Reading.Actual -> fmt(r.value) to C.text
        is Reading.Estimate -> "~" + fmt(r.value) to C.amber
        is Reading.Inaccessible -> "N/A" to C.dim
    }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = Body.copy(color = C.dim))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(txt, style = MonoSm.copy(color = col))
                Text(r.tag(), style = Label.copy(color = if (r is Reading.Actual) C.green else if (r is Reading.Estimate) C.amber else C.dim))
            }
        }
        if (r is Reading.Inaccessible) Text(r.reason, style = Label)
    }
}

@Composable
fun LevelChip(level: dev.opr.engine.thermal.Level) {
    Box(Modifier.background(C.level(level).copy(alpha = 0.18f), RoundedCornerShape(50)).border(1.dp, C.level(level), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text(level.name, style = MonoSm.copy(color = C.level(level)))
    }
}

/** Animated multi-series line graph. Y-range eases toward the data range for smooth transitions. */
@Composable
fun LineGraph(
    title: String, unit: String, series: List<Pair<String, List<Float>>>, colors: List<Color>,
    modifier: Modifier = Modifier, fixedMin: Float? = null, fixedMax: Float? = null,
) {
    val all = series.flatMap { it.second }
    val dataMin = fixedMin ?: (all.minOrNull() ?: 0f)
    val dataMax = fixedMax ?: (all.maxOrNull() ?: 1f).let { if (it <= dataMin) dataMin + 1f else it }
    val lo by animateFloatAsState(dataMin, tween(400), label = "lo")
    val hi by animateFloatAsState(dataMax, tween(400), label = "hi")
    Panel(title, modifier) {
        if (all.isEmpty()) { Text("No data yet (metric unavailable or not sampled)", style = Label); return@Panel }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            series.forEachIndexed { i, (n, v) ->
                v.lastOrNull()?.let { Text("$n %.1f$unit".format(it), style = MonoSm.copy(color = colors[i % colors.size])) }
            }
        }
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val span = (hi - lo).coerceAtLeast(0.001f)
            for (g in 0..3) { val y = size.height * g / 3f; drawLine(C.line, Offset(0f, y), Offset(size.width, y), 1f) }
            series.forEachIndexed { i, (_, v) ->
                if (v.size < 2) return@forEachIndexed
                val p = Path()
                v.forEachIndexed { k, y ->
                    val px = size.width * k / (v.size - 1).coerceAtLeast(1)
                    val py = size.height - (y - lo) / span * size.height
                    if (k == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                drawPath(p, colors[i % colors.size], style = Stroke(width = 3f))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("%.0f$unit".format(lo), style = Label); Text("%.0f$unit".format(hi), style = Label)
        }
    }
}

/** One cell per second, colour = OS thermal status. */
@Composable
fun ThrottleTimeline(status: List<Int>) {
    Panel("Thermal throttling timeline (OS status, 1 cell = 1 s)") {
        Canvas(Modifier.fillMaxWidth().height(26.dp)) {
            if (status.isEmpty()) return@Canvas
            val w = size.width / status.size
            status.forEachIndexed { i, s ->
                val c = when (s) { 0 -> C.green; 1 -> C.yellow; 2, 3 -> C.orange; else -> C.red }
                drawRect(c.copy(alpha = 0.85f), Offset(i * w, 0f), androidx.compose.ui.geometry.Size(w + 0.5f, size.height))
            }
        }
        Text("green NONE · yellow LIGHT · orange MODERATE/SEVERE · red CRITICAL+", style = Label)
    }
}
