package dev.opr.engine.data

/** Every metric is tagged with its provenance so the UI never shows an estimate as a measurement. */
sealed interface Reading<out T> {
    /** Value read directly from the OS/kernel. [source] names the API or file. */
    data class Actual<T>(val value: T, val source: String) : Reading<T>

    /** Derived value; [basis] explains how it was computed. */
    data class Estimate<T>(val value: T, val basis: String) : Reading<T>

    /** Could not be read. We never substitute a made-up number. */
    data class Inaccessible(val reason: String) : Reading<Nothing>
}

fun <T> Reading<T>.valueOrNull(): T? = when (this) {
    is Reading.Actual -> value
    is Reading.Estimate -> value
    is Reading.Inaccessible -> null
}

fun <T> Reading<T>.tag(): String = when (this) {
    is Reading.Actual -> "ACTUAL"
    is Reading.Estimate -> "ESTIMATE"
    is Reading.Inaccessible -> "N/A"
}

fun <T> Reading<T>.detail(): String = when (this) {
    is Reading.Actual -> source
    is Reading.Estimate -> basis
    is Reading.Inaccessible -> reason
}

data class CpuCore(
    val id: Int,
    val online: Reading<Boolean>,
    val curKhz: Reading<Long>,
    val utilPct: Reading<Float>,
)

data class CpuPolicy(
    val id: Int,
    val cpus: List<Int>,
    val hwMinKhz: Reading<Long>,
    val hwMaxKhz: Reading<Long>,
    val scalingMinKhz: Reading<Long>,
    val scalingMaxKhz: Reading<Long>,
    val curKhz: Reading<Long>,
    val governor: Reading<String>,
    val availableGovernors: Reading<List<String>>,
    val availableFreqsKhz: Reading<List<Long>>,
) {
    /** How far the kernel/vendor stack has lowered this cluster's ceiling below the hardware maximum (0..100). */
    val ceilingReductionPct: Float?
        get() {
            val hw = hwMaxKhz.valueOrNull() ?: return null
            val sc = scalingMaxKhz.valueOrNull() ?: return null
            if (hw <= 0) return null
            return ((1f - sc.toFloat() / hw) * 100f).coerceIn(0f, 100f)
        }
}

data class CpuSnapshot(
    val socModel: Reading<String>,
    val abi: String,
    val coreClusterNote: String,
    val cores: List<CpuCore>,
    val policies: List<CpuPolicy>,
)

data class GpuSnapshot(
    val model: Reading<String>,
    val curHz: Reading<Long>,
    val maxHz: Reading<Long>,
    val busyPct: Reading<Float>,
    val tempC: Reading<Float>,
)

enum class ThermalClass { CPU, GPU, BATTERY, SKIN, OTHER }

data class ThermalZone(
    val id: Int,
    val type: String,
    val tempC: Reading<Float>,
    /** Inferred from the zone's name only. Not an authoritative mapping. */
    val cls: ThermalClass,
)

data class ThermalSnapshot(
    val zones: List<ThermalZone>,
    /** android.os.PowerManager thermal status 0..6 (NONE..SHUTDOWN). */
    val osStatus: Reading<Int>,
    val headroom: Reading<Float>,
)

data class BatterySnapshot(
    val tempC: Reading<Float>,
    val voltageMv: Reading<Int>,
    /** Signed microamps as reported by BatteryManager. Sign convention is OEM-specific; see currentNote. */
    val currentUa: Reading<Long>,
    val powerMw: Reading<Float>,
    val levelPct: Reading<Int>,
    val charging: Reading<Boolean>,
    val health: Reading<String>,
    val healthIsOverheat: Boolean,
    val cycleCount: Reading<Int>,
    val capacityHealthPct: Reading<Float>,
)

data class MemorySnapshot(
    val totalMb: Reading<Long>,
    val availMb: Reading<Long>,
    val usedPct: Reading<Float>,
    val lowMemory: Reading<Boolean>,
    val psiSomeAvg10: Reading<Float>,
)

data class SystemSnapshot(
    val tsMs: Long,
    val cpu: CpuSnapshot,
    val gpu: GpuSnapshot,
    val thermal: ThermalSnapshot,
    val battery: BatterySnapshot,
    val memory: MemorySnapshot,
)
