package dev.opr.engine.collect

import android.os.Build
import dev.opr.engine.data.*

class CpuCollector {
    private var prevStat: Map<Int, LongArray> = emptyMap()
    private val cpuRoot = "/sys/devices/system/cpu"

    fun collect(): CpuSnapshot {
        val ids = Sysfs.list(cpuRoot).filter { Regex("cpu\\d+").matches(it) }
            .map { it.removePrefix("cpu").toInt() }.sorted()
            .ifEmpty { (0 until Runtime.getRuntime().availableProcessors()).toList() }

        val util = readUtil()
        val onlineRaw = Sysfs.readAll(ids.map { "$cpuRoot/cpu$it/online" })
        val freqRaw = Sysfs.readAll(ids.map { "$cpuRoot/cpu$it/cpufreq/scaling_cur_freq" })

        val cores = ids.mapIndexed { i, id ->
            CpuCore(
                id = id,
                // cpu0 usually has no "online" node; absence is not evidence of being offline.
                online = onlineRaw[i]?.let { Reading.Actual(it.trim() == "1", "$cpuRoot/cpu$id/online") }
                    ?: Reading.Inaccessible("no online node (core cannot be hot-plugged, or blocked)"),
                curKhz = Sysfs.long("$cpuRoot/cpu$id/cpufreq/scaling_cur_freq", freqRaw[i]),
                utilPct = util[id]?.let { Reading.Actual(it, "/proc/stat delta") }
                    ?: Reading.Inaccessible("/proc/stat is not readable by normal apps on modern Android (SELinux); use adb shell or root"),
            )
        }
        return CpuSnapshot(
            socModel = Reading.Actual("${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL} (hw=${Build.HARDWARE})", "android.os.Build"),
            abi = Build.SUPPORTED_ABIS.joinToString(),
            coreClusterNote = "Cluster layout is derived from cpufreq policy groups below, not assumed.",
            cores = cores,
            policies = readPolicies(),
        )
    }

    private fun readPolicies(): List<CpuPolicy> {
        val dirs = Sysfs.list("$cpuRoot/cpufreq").filter { it.startsWith("policy") }
            .sortedBy { it.removePrefix("policy").toIntOrNull() ?: 0 }
        return dirs.map { d ->
            val p = "$cpuRoot/cpufreq/$d"
            val names = listOf(
                "related_cpus", "cpuinfo_min_freq", "cpuinfo_max_freq", "scaling_min_freq",
                "scaling_max_freq", "scaling_cur_freq", "scaling_governor",
                "scaling_available_governors", "scaling_available_frequencies",
            )
            val r = Sysfs.readAll(names.map { "$p/$it" })
            CpuPolicy(
                id = d.removePrefix("policy").toIntOrNull() ?: -1,
                cpus = r[0]?.split(Regex("\\s+"))?.mapNotNull { it.toIntOrNull() } ?: emptyList(),
                hwMinKhz = Sysfs.long("$p/${names[1]}", r[1]),
                hwMaxKhz = Sysfs.long("$p/${names[2]}", r[2]),
                scalingMinKhz = Sysfs.long("$p/${names[3]}", r[3]),
                scalingMaxKhz = Sysfs.long("$p/${names[4]}", r[4]),
                curKhz = Sysfs.long("$p/${names[5]}", r[5]),
                governor = Sysfs.text("$p/${names[6]}", r[6]),
                availableGovernors = r[7]?.let { Reading.Actual(it.split(Regex("\\s+")), "$p/${names[7]}") }
                    ?: Reading.Inaccessible("unreadable"),
                availableFreqsKhz = r[8]?.let { s ->
                    Reading.Actual(s.split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }, "$p/${names[8]}")
                } ?: Reading.Inaccessible("scaling_available_frequencies absent (common on Qualcomm kernels using OPP tables)"),
            )
        }
    }

    /** Per-core utilisation from /proc/stat deltas; empty map if not readable. */
    private fun readUtil(): Map<Int, Float> {
        val raw = Sysfs.read("/proc/stat") ?: return emptyMap()
        val cur = HashMap<Int, LongArray>()
        for (line in raw.lineSequence()) {
            val m = Regex("^cpu(\\d+)\\s+(.*)$").find(line) ?: continue
            val f = m.groupValues[2].trim().split(Regex("\\s+")).map { it.toLongOrNull() ?: 0L }
            if (f.size < 7) continue
            val idle = f[3] + f[4]
            val total = f.take(8).sum()
            cur[m.groupValues[1].toInt()] = longArrayOf(total, idle)
        }
        val out = HashMap<Int, Float>()
        for ((id, c) in cur) {
            val p = prevStat[id] ?: continue
            val dt = c[0] - p[0]
            val di = c[1] - p[1]
            if (dt > 0) out[id] = ((dt - di).toFloat() / dt * 100f).coerceIn(0f, 100f)
        }
        prevStat = cur
        return out
    }
}
