package dev.opr.engine.game

import kotlin.math.ceil
import kotlin.math.sqrt

data class FrameStats(
    val frames: Int,
    val windowSec: Double,
    val avgFps: Double,
    /** Mean FPS of the slowest 1% of frames (industry-standard "1% low"). */
    val onePctLowFps: Double,
    val p99FrameMs: Double,
    val meanFrameMs: Double,
    /** Std-dev of frame intervals (ms): lower = more consistent. */
    val jitterMs: Double,
    /** Frames whose interval exceeded 1.5x the target interval. */
    val drops: Int,
    val dropPct: Double,
    /** Share of frames within 1.25x the target interval. 100 = perfectly paced. */
    val stabilityPct: Double,
    val targetFps: Int,
)

object FrameStatsAnalyzer {

    /** @param presentNs strictly increasing frame present timestamps in nanoseconds. */
    fun analyze(presentNs: LongArray, targetFps: Int): FrameStats? {
        if (presentNs.size < 10 || targetFps <= 0) return null
        val iv = ArrayList<Double>(presentNs.size)
        for (i in 1 until presentNs.size) {
            val d = (presentNs[i] - presentNs[i - 1]) / 1e6
            // Gaps >= 1 s are loading screens/pauses, not rendering performance.
            if (d > 0 && d < 1000) iv += d
        }
        if (iv.size < 9) return null
        val mean = iv.average()
        val sorted = iv.sortedDescending()
        val worstN = maxOf(1, ceil(iv.size * 0.01).toInt())
        val worstMean = sorted.take(worstN).average()
        val p99 = sorted[minOf(sorted.size - 1, maxOf(0, ceil(iv.size * 0.01).toInt() - 1))]
        val target = 1000.0 / targetFps
        val drops = iv.count { it > 1.5 * target }
        val within = iv.count { it <= 1.25 * target }
        val variance = iv.sumOf { (it - mean) * (it - mean) } / iv.size
        return FrameStats(
            frames = iv.size + 1,
            windowSec = (presentNs.last() - presentNs.first()) / 1e9,
            avgFps = 1000.0 / mean,
            onePctLowFps = 1000.0 / worstMean,
            p99FrameMs = p99,
            meanFrameMs = mean,
            jitterMs = sqrt(variance),
            drops = drops,
            dropPct = 100.0 * drops / iv.size,
            stabilityPct = 100.0 * within / iv.size,
            targetFps = targetFps,
        )
    }
}

/**
 * Parses `dumpsys SurfaceFlinger --latency <layer>` output.
 * Line 1: refresh period (ns). Following lines: desiredPresent, actualPresent, frameReady (ns).
 * Rows with actualPresent == 0 or Long.MAX_VALUE are unfilled ring-buffer slots and are skipped.
 * Format is documented in AOSP; it is NOT verified on OxygenOS 16 — confirm with docs/ADB_COMMANDS.md.
 */
object SurfaceFlingerLatencyParser {
    data class Parsed(val refreshPeriodNs: Long, val presentNs: LongArray)

    fun parse(text: String): Parsed? {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 2) return null
        val period = lines[0].toLongOrNull() ?: return null
        val present = lines.drop(1).mapNotNull { l ->
            val f = l.split(Regex("\\s+"))
            if (f.size < 3) null else f[1].toLongOrNull()?.takeIf { it > 0 && it != Long.MAX_VALUE }
        }.distinct().sorted()
        return Parsed(period, present.toLongArray())
    }
}

/** Accumulates de-duplicated present timestamps across polls and exposes a sliding window. */
class FrameWindow(private val windowNs: Long = 30_000_000_000L) {
    private val ts = ArrayDeque<Long>()
    @Synchronized fun add(newTimestamps: LongArray) {
        val last = ts.lastOrNull() ?: Long.MIN_VALUE
        for (t in newTimestamps.sorted()) if (t > last && (ts.isEmpty() || t > ts.last())) ts.addLast(t)
        val cutoff = (ts.lastOrNull() ?: 0L) - windowNs
        while (ts.isNotEmpty() && ts.first() < cutoff) ts.removeFirst()
    }
    @Synchronized fun snapshot(): LongArray = ts.toLongArray()
    @Synchronized fun clear() = ts.clear()
}
