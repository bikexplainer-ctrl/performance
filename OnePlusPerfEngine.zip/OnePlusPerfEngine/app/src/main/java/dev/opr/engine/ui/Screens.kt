package dev.opr.engine.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.opr.engine.collect.ThermalCollector
import dev.opr.engine.data.*
import dev.opr.engine.game.*
import dev.opr.engine.root.*
import dev.opr.engine.service.*
import dev.opr.engine.thermal.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content,
)

@Composable
fun OverviewScreen(h: HubState) = Page {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column { Text("HEALTH", style = Label); LevelChip(h.level) }
        Column { Text("PERF SCORE (est.)", style = Label); Text(h.perfScore?.toString() ?: "--", style = Big) }
        Button(onClick = { if (h.running) MonitorService.stop(ctx) else MonitorService.start(ctx) }) { Text(if (h.running) "Stop" else "Start") }
    }
    if (h.perfScoreBasis.isNotEmpty()) Text(h.perfScoreBasis, style = Label)
    val s = h.snapshot
    if (s == null) { Text("Press Start to begin read-only monitoring.", style = Body); return@Page }

    LineGraph("CPU frequency per cluster", " MHz",
        h.series.filterKeys { it.startsWith("cpu") && it.endsWith("Mhz") }.map { it.key.removePrefix("cpu").removeSuffix("Mhz").let { n -> "pol$n" } to it.value },
        listOf(C.cyan, C.violet, C.lime, C.amber))
    LineGraph("GPU frequency", " MHz", listOf("gpu" to (h.series["gpuMhz"] ?: emptyList())), listOf(C.lime))
    LineGraph("Temperatures", "°C", ThermalClass.values().mapNotNull { c -> h.series["t_${c.name}"]?.let { c.name to it } }, listOf(C.red, C.orange, C.amber, C.cyan, C.dim))
    LineGraph("RAM utilisation", "%", listOf("ram" to (h.series["ram"] ?: emptyList())), listOf(C.violet), fixedMin = 0f, fixedMax = 100f)
    LineGraph("FPS (avg / 1% low)", "", listOf("avg" to (h.series["fps"] ?: emptyList()), "1%low" to (h.series["fps1"] ?: emptyList())), listOf(C.green, C.orange))
    ThrottleTimeline(h.throttleTimeline)

    Panel("Battery") {
        ReadingRow("Temperature", s.battery.tempC) { "%.1f °C".format(it) }
        ReadingRow("Voltage", s.battery.voltageMv) { "$it mV" }
        ReadingRow("Current (OEM sign)", s.battery.currentUa) { "%.0f mA".format(it / 1000f) }
        ReadingRow("Power", s.battery.powerMw) { "%.0f mW".format(it) }
        ReadingRow("Health flag", s.battery.health)
        ReadingRow("Cycle count", s.battery.cycleCount)
        ReadingRow("Capacity vs design", s.battery.capacityHealthPct) { "%.0f %%".format(it) }
    }
    Panel("Memory") {
        ReadingRow("Total", s.memory.totalMb) { "$it MB" }
        ReadingRow("Available", s.memory.availMb) { "$it MB" }
        ReadingRow("Used", s.memory.usedPct) { "%.0f %%".format(it) }
        ReadingRow("Low-memory flag", s.memory.lowMemory)
        ReadingRow("PSI some avg10", s.memory.psiSomeAvg10) { "%.2f %%".format(it) }
    }
    WarningsPanel(h.warnings)
    BackgroundPanel()
}

@Composable
fun WarningsPanel(w: List<Warning>) = Panel("Safety indicators") {
    if (w.isEmpty()) Text("GREEN — no active warnings from accessible sensors.", style = Body.copy(color = C.green))
    w.forEach {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { LevelChip(it.level); Text(it.metric, style = Body) }
            Text("Current: ${it.current}", style = MonoSm)
            Text("Reference limit: ${it.referenceLimit}", style = MonoSm)
            Text("Difference: ${it.difference}", style = MonoSm)
            Text("Consequence: ${it.consequences}", style = Label)
            Text("Action: ${it.action}", style = Body)
        }
        HorizontalDivider(color = C.line)
    }
}

@Composable
fun BackgroundPanel() = Panel("Background resource usage") {
    val ctx = LocalContext.current
    var rows by remember { mutableStateOf<List<String>?>(null) }
    val scope = rememberCoroutineScope()
    Text("Normal apps cannot see other apps' CPU/RAM on modern Android. Options: foreground-time ranking (needs Usage Access) or root `top`.", style = Label)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { scope.launch { rows = withContext(Dispatchers.IO) { UsageRanking.top(ctx) } } }) { Text("Usage ranking") }
        OutlinedButton(onClick = { scope.launch { rows = withContext(Dispatchers.IO) { listOf(RootShell.exec("top -b -n 1 -m 12 -o PID,%CPU,RES,ARGS", 8).let { if (it.ok) it.out else "root top failed: ${it.err}" }) } } }) { Text("Root top") }
    }
    rows?.forEach { Text(it, style = MonoSm) }
}

@Composable
fun CpuGpuScreen(h: HubState) = Page {
    val s = h.snapshot ?: run { Text("Start monitoring first.", style = Body); return@Page }
    Panel("SoC") {
        ReadingRow("SoC", s.cpu.socModel); Text("ABI ${s.cpu.abi}", style = MonoSm); Text(s.cpu.coreClusterNote, style = Label)
        Text("Reader: ${if (Sysfs.usingNative) "NDK (native)" else "java.io fallback"}", style = Label)
    }
    s.cpu.policies.forEach { p ->
        Panel("cpufreq policy${p.id}  ·  CPUs ${p.cpus.joinToString()}") {
            ReadingRow("Current", p.curKhz) { "${it / 1000} MHz" }
            ReadingRow("HW min", p.hwMinKhz) { "${it / 1000} MHz" }
            ReadingRow("HW max", p.hwMaxKhz) { "${it / 1000} MHz" }
            ReadingRow("Scaling min", p.scalingMinKhz) { "${it / 1000} MHz" }
            ReadingRow("Scaling max (ceiling)", p.scalingMaxKhz) { "${it / 1000} MHz" }
            ReadingRow("Governor", p.governor)
            ReadingRow("Available governors", p.availableGovernors) { it.joinToString() }
            p.ceilingReductionPct?.let { Text("Ceiling reduction vs HW max: %.1f%%".format(it), style = MonoSm) }
        }
    }
    Panel("Per-core") {
        s.cpu.cores.forEach { c ->
            val f = c.curKhz.valueOrNull()?.let { "${it / 1000} MHz" } ?: "N/A"
            val u = c.utilPct.valueOrNull()?.let { "%.0f%%".format(it) } ?: "util N/A"
            Text("cpu${c.id}  $f  $u  online=${c.online.valueOrNull() ?: "?"}", style = MonoSm)
        }
        if (s.cpu.cores.none { it.utilPct is Reading.Actual }) Text("Per-core utilisation needs /proc/stat (blocked for apps). Use adb or root; see docs/ADB_COMMANDS.md.", style = Label)
    }
    Panel("GPU") {
        ReadingRow("Renderer", s.gpu.model); ReadingRow("Current", s.gpu.curHz) { "${it / 1_000_000} MHz" }
        ReadingRow("Max", s.gpu.maxHz) { "${it / 1_000_000} MHz" }; ReadingRow("Busy", s.gpu.busyPct) { "%.0f %%".format(it) }
        ReadingRow("Temp", s.gpu.tempC) { "%.1f °C".format(it) }
    }
}

@Composable
fun ThermalScreen(h: HubState) = Page {
    val ctx = LocalContext.current
    val store = remember { ThresholdStore(ctx) }
    val s = h.snapshot ?: run { Text("Start monitoring first.", style = Body); return@Page }
    Panel("Android thermal API") {
        ReadingRow("Status", s.thermal.osStatus) { ThermalCollector.statusName(it) }
        ReadingRow("Headroom (10 s forecast)", s.thermal.headroom) { "%.2f".format(it) }
        Text("Headroom 1.0 ≈ SEVERE throttling threshold (Android definition).", style = Label)
    }
    Panel("Thermal zones (${s.thermal.zones.size})") {
        if (s.thermal.zones.none { it.tempC is Reading.Actual }) Text("Zone temperatures are blocked for this app by SELinux. Battery temperature and OS thermal status remain available.", style = Label)
        s.thermal.zones.forEach { z -> Text("${z.id} ${z.type} [${z.cls}*] " + (z.tempC.valueOrNull()?.let { "%.1f °C".format(it) } ?: "N/A"), style = MonoSm) }
        Text("*class inferred from zone name only.", style = Label)
    }
    Panel("Component limits (reference)") {
        ThermalClass.values().filter { it != ThermalClass.OTHER }.forEach { c ->
            Text("${c.name}: " + (VerifiedLimits.forClass(c)?.let { "%.0f °C — ${it.citation}".format(it.valueC) } ?: "UNKNOWN (no verified manufacturer limit)"), style = MonoSm)
        }
    }
    Panel("Your warning thresholds (USER-SET, unverified)") {
        var cur by remember { mutableStateOf(store.load()) }
        ThermalClass.values().filter { it != ThermalClass.OTHER }.forEach { c ->
            val t = cur.byClass[c] ?: ClassThresholds()
            var y by remember { mutableStateOf(t.yellow?.toString() ?: "") }
            var o by remember { mutableStateOf(t.orange?.toString() ?: "") }
            var r by remember { mutableStateOf(t.red?.toString() ?: "") }
            Text(c.name, style = Label)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(Triple("Y", y) { v: String -> y = v }, Triple("O", o) { v: String -> o = v }, Triple("R", r) { v: String -> r = v }).forEach { (l, v, set) ->
                    OutlinedTextField(v, set, label = { Text("$l °C") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            OutlinedButton(onClick = { store.set(c, y.toFloatOrNull(), o.toFloatOrNull(), r.toFloatOrNull()); cur = store.load() }) { Text("Save ${c.name}") }
        }
    }
    LineGraph("Temperatures", "°C", ThermalClass.values().mapNotNull { c -> h.series["t_${c.name}"]?.let { c.name to it } }, listOf(C.red, C.orange, C.amber, C.cyan, C.dim))
    ThrottleTimeline(h.throttleTimeline)
    WarningsPanel(h.warnings)
}

@Composable
fun GameScreen(h: HubState) = Page {
    var target by remember { mutableStateOf(120) }
    var paste by remember { mutableStateOf("") }
    var rootPoll by remember { mutableStateOf(MonitorService.gameLayerPolling) }
    MonitorService.targetFps = target
    Panel("BGMI analysis (com.pubg.imobile)") {
        Text("Android does not let a normal app read another app's frame timing. Sources: (1) root polling of SurfaceFlinger, (2) paste `adb shell dumpsys SurfaceFlinger --latency <layer>` output. Nothing touches the game, its files or anti-cheat.", style = Label)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(60, 90, 120).forEach { FilterChip(target == it, { target = it }, { Text("$it fps") }) } }
        Row { Switch(rootPoll, { rootPoll = it; MonitorService.gameLayerPolling = it }); Spacer(Modifier.width(8.dp)); Text("Root: poll game layer (read-only dumpsys)", style = Body) }
        OutlinedTextField(paste, { paste = it }, label = { Text("Paste dumpsys output") }, modifier = Modifier.fillMaxWidth(), maxLines = 4)
        Button(onClick = { SurfaceFlingerLatencyParser.parse(paste)?.let { MonitorService.externalFrames = it.presentNs } }) { Text("Analyse pasted data") }
    }
    val fs = h.frameStats
    Panel("Frame statistics  (source: ${h.frameSource})") {
        if (fs == null) Text("No frame data yet.", style = Body) else {
            Text("Avg FPS ${"%.1f".format(fs.avgFps)}   1% low ${"%.1f".format(fs.onePctLowFps)}", style = Big)
            Text("Frame time mean %.2f ms · p99 %.2f ms · jitter σ %.2f ms".format(fs.meanFrameMs, fs.p99FrameMs, fs.jitterMs), style = MonoSm)
            Text("Drops (>1.5× target) ${fs.drops} (%.1f%%) · in-target %.0f%% · window %.0f s · %d frames".format(fs.dropPct, fs.stabilityPct, fs.windowSec, fs.frames), style = MonoSm)
        }
    }
    h.bottleneck?.let { b ->
        Panel("Bottleneck (ESTIMATE): ${b.kind}") { b.evidence.forEach { Text("• $it", style = Body) } }
        Panel("Stable-120 profile advice") { GamingProfile.advise(fs, b, h.level).forEach { Text("• $it", style = Body) } }
    }
}

@Composable
fun AnalysisScreen(h: HubState) = Page {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<CompatRow>?>(null) }
    var rootOk by remember { mutableStateOf<Boolean?>(null) }
    Panel("Compatibility report") {
        Text("Read-only probe. Root is only contacted if you press 'Probe with root'.", style = Label)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { h.snapshot?.let { s -> scope.launch { rows = withContext(Dispatchers.IO) { CompatProbe.run(s, false) } } } }) { Text("Probe (no root)") }
            OutlinedButton(onClick = { h.snapshot?.let { s -> scope.launch { rows = withContext(Dispatchers.IO) { val ok = RootShell.isRootAvailable(); rootOk = ok; CompatProbe.run(s, ok) } } } }) { Text("Probe with root") }
        }
        if (h.snapshot == null) Text("Start monitoring first.", style = Label)
        rootOk?.let { Text(if (it) "Root: available" else "Root: not available", style = MonoSm) }
    }
    rows?.forEach { r ->
        Panel("${r.parameter}  ·  ${r.restriction.label}") {
            Text("Readable: ${r.readable}", style = MonoSm); Text("Writable: ${r.writable}", style = MonoSm)
            Text("To modify: ${r.modifiability}", style = Body); Text(r.appBehaviour, style = Label)
        }
    }
    if (rootOk == true) RootPanel(h)
}

@Composable
fun RootPanel(h: HubState) = Panel("Advanced (root): select a frequency within the kernel's own table") {
    val s = h.snapshot ?: return@Panel
    var policyIdx by remember { mutableStateOf(0) }
    var maxText by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf<PlanResult?>(null) }
    var msg by remember { mutableStateOf("") }
    var lastApplied by remember { mutableStateOf<List<TuningChange>>(emptyList()) }
    val p = s.cpu.policies.getOrNull(policyIdx) ?: return@Panel
    Text("This module cannot exceed cpuinfo_max_freq, edit thermal/voltage/battery nodes, or run silently. Vendor perf services may revert values.", style = Label)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { s.cpu.policies.forEachIndexed { i, q -> FilterChip(i == policyIdx, { policyIdx = i; plan = null }, { Text("policy${q.id}") }) } }
    Text("Available kHz: ${p.availableFreqsKhz.valueOrNull()?.joinToString() ?: "not exposed"}", style = Label)
    OutlinedTextField(maxText, { maxText = it }, label = { Text("New scaling_max_freq (kHz)") }, singleLine = true)
    OutlinedButton(onClick = { plan = RootTuner.plan(p, maxText.toLongOrNull(), null, null, s.thermal.osStatus.valueOrNull() ?: 0) }) { Text("Preview change") }
    when (val pl = plan) {
        is PlanResult.Rejected -> Text("Rejected: ${pl.why}", style = Body.copy(color = C.red))
        is PlanResult.Ok -> {
            pl.changes.forEach { Text("${it.path}\n  ${it.oldValue} → ${it.newValue}", style = MonoSm) }
            var confirm by remember { mutableStateOf(false) }
            Row { Checkbox(confirm, { confirm = it }); Text("I understand this writes to a kernel interface and I confirm exactly these changes.", style = Body) }
            Button(enabled = confirm, onClick = {
                val r = RootTuner.apply(pl.changes); lastApplied = r.applied
                msg = r.failed?.let { "FAILED, rolled back: $it" } ?: "Applied and verified by readback. Benchmark before trusting it."
            }) { Text("Apply") }
        }
        null -> {}
    }
    if (lastApplied.isNotEmpty()) OutlinedButton(onClick = { RootTuner.revert(lastApplied); lastApplied = emptyList(); msg = "Reverted." }) { Text("Revert last change") }
    if (msg.isNotEmpty()) Text(msg, style = Body)
}
