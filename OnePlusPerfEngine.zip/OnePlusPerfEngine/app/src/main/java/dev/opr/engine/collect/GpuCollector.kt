package dev.opr.engine.collect

import android.opengl.EGL14
import android.opengl.GLES20
import dev.opr.engine.data.*

/**
 * Adreno GPU metrics come from the kgsl driver. Whether a normal app may read them depends on SELinux policy on
 * OxygenOS 16; every read is therefore reported as ACTUAL or N/A, never guessed.
 * Paths are common kgsl nodes, not verified for the OnePlus 15R. Use docs/ADB_COMMANDS.md to confirm on-device.
 */
class GpuCollector {
    private val base = "/sys/class/kgsl/kgsl-3d0"
    private val modelCache: Reading<String> by lazy { queryRenderer() }

    fun collect(): GpuSnapshot {
        val paths = listOf(
            "$base/devfreq/cur_freq", "$base/gpuclk", "$base/devfreq/max_freq", "$base/max_gpuclk",
            "$base/gpu_busy_percentage", "$base/temp",
        )
        val r = Sysfs.readAll(paths)
        val cur = Sysfs.long(paths[0], r[0]).let { if (it is Reading.Actual) it else Sysfs.long(paths[1], r[1]) }
        val max = Sysfs.long(paths[2], r[2]).let { if (it is Reading.Actual) it else Sysfs.long(paths[3], r[3]) }
        val busy: Reading<Float> = r[4]?.let { s ->
            s.replace("%", "").trim().toFloatOrNull()?.let { Reading.Actual(it, paths[4]) }
        } ?: Reading.Inaccessible("kgsl gpu_busy_percentage not readable by this app")
        val temp: Reading<Float> = r[5]?.trim()?.toFloatOrNull()?.let {
            Reading.Actual(if (it > 200f) it / 1000f else it, paths[5])
        } ?: Reading.Inaccessible("kgsl temp not readable; GPU temperature may still appear in thermal zones")
        return GpuSnapshot(modelCache, cur, max, busy, temp)
    }

    private fun queryRenderer(): Reading<String> = try {
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val cfgAttr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE)
        val cfg = arrayOfNulls<android.opengl.EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfg, 0, 1, n, 0)
        val ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreatePbufferSurface(dpy, cfg[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, ctx)
        val renderer = GLES20.glGetString(GLES20.GL_RENDERER)
        val vendor = GLES20.glGetString(GLES20.GL_VENDOR)
        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(dpy, surf); EGL14.eglDestroyContext(dpy, ctx); EGL14.eglTerminate(dpy)
        if (renderer != null) Reading.Actual("$vendor $renderer", "GLES20.glGetString(GL_RENDERER)")
        else Reading.Inaccessible("GL renderer string unavailable")
    } catch (t: Throwable) {
        Reading.Inaccessible("EGL query failed: ${t.javaClass.simpleName}")
    }
}
