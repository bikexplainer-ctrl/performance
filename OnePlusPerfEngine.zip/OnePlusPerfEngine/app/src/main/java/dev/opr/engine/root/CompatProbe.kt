package dev.opr.engine.root

import android.os.Build
import dev.opr.engine.data.*

enum class RestrictionClass(val label: String) {
    A("A: Android software"), B("B: Kernel-enforced"), C("C: Firmware-enforced"), D("D: Hardware-enforced")
}

data class CompatRow(
    val parameter: String,
    val restriction: RestrictionClass,
    /** Result of a live READ-ONLY probe on this device. */
    val readable: String,
    /** Live probe result for writability (only determined when root is available; otherwise "requires root (not probed)"). */
    val writable: String,
    /** What it takes to change it. Static analysis; unverified on the 15R unless stated. */
    val modifiability: String,
    val appBehaviour: String,
)

/**
 * Compatibility probe. It never writes. Writability is tested with `test -w` through su only when the user has
 * explicitly run the root probe; otherwise it is reported as not probed.
 */
object CompatProbe {
    fun run(snapshot: SystemSnapshot, rootAvailable: Boolean): List<CompatRow> {
        val p0 = snapshot.cpu.policies.firstOrNull()
        fun w(path: String): String = if (!rootAvailable) "not probed (no root)" else
            if (RootShell.exec("test -e $path && test -w $path && echo W || echo NO").out.contains("W")) "writable by root (DAC)" else "not writable / absent"
        fun r(x: Reading<*>) = if (x is Reading.Inaccessible) "NO: ${x.reason}" else "YES (${x.detail()})"
        fun path(n: String) = p0?.let { "/sys/devices/system/cpu/cpufreq/policy${it.id}/$n" } ?: "/nonexistent"

        val vbs = getprop("ro.boot.verifiedbootstate"); val locked = getprop("ro.boot.flash.locked")
        return listOf(
            CompatRow("CPU frequency ceiling (scaling_max_freq)", RestrictionClass.B,
                p0?.let { r(it.scalingMaxKhz) } ?: "NO: no cpufreq policy visible", w(path("scaling_max_freq")),
                "Within the kernel OPP table: root. Above it: not possible without a custom kernel with extra OPPs; availability for 15R unverified.",
                "Read-only for non-root. Root module can only choose an existing OPP ≤ cpuinfo_max_freq."),
            CompatRow("CPU hardware max (cpuinfo_max_freq)", RestrictionClass.D,
                p0?.let { r(it.hwMaxKhz) } ?: "NO", "read-only attribute (not a tunable)",
                "Defined by silicon bins/OPP+voltage tables in firmware/devicetree. Cannot be modified by an app.",
                "Used as the reference for 'performance degradation'."),
            CompatRow("CPU governor", RestrictionClass.B,
                p0?.let { r(it.governor) } ?: "NO", w(path("scaling_governor")),
                "Root (switch among scaling_available_governors). Vendor perf services may override at runtime.",
                "Root module offers only governors listed by the kernel, with confirmation, readback and rollback."),
            CompatRow("Core parking / hotplug (core_ctl, online)", RestrictionClass.B,
                snapshot.cpu.cores.firstOrNull { it.online is Reading.Actual }?.let { "PARTIAL: online state readable" } ?: "NO",
                "not probed", "Kernel scheduler/core_ctl; root-only, vendor tuned. This app only observes it.",
                "Observed only. No writes implemented."),
            CompatRow("Thermal throttling policy", RestrictionClass.C,
                if (snapshot.thermal.zones.any { it.tempC is Reading.Actual }) "YES: zone temps readable" else "NO: zone temps blocked",
                "n/a", "Enforced by vendor thermal HAL/daemon and kernel thermal framework. This app will NOT disable or alter it.",
                "Display and trend analysis only."),
            CompatRow("GPU frequency / governor (kgsl devfreq)", RestrictionClass.B,
                r(snapshot.gpu.curHz), w("/sys/class/kgsl/kgsl-3d0/devfreq/max_freq"),
                "Root can usually select within the GPU OPP table; above table needs custom kernel. Unverified on 15R.",
                "Read-only in this app (GPU writes not implemented)."),
            CompatRow("Voltage control", RestrictionClass.D,
                "NO: no standard readable/writable interface used by this app", "not implemented",
                "Rails are managed by PMIC/RPMh firmware; changes are not exposed through documented kernel interfaces on stock kernels.",
                "Not implemented, by design (would risk instability/damage)."),
            CompatRow("Battery/charger limits & emergency shutdown", RestrictionClass.C,
                "partial: temp/voltage/health via BatteryManager", "n/a",
                "Fuel-gauge/charger firmware. Must not be altered; this app never touches it.", "Display only."),
            CompatRow("Refresh rate / frame pacing / Game Mode", RestrictionClass.A,
                "YES via Android APIs/settings", "user-controlled in Settings/Game Assistant",
                "Android/OxygenOS software setting; safe to change through the official UI.", "Advice only."),
            CompatRow("Bootloader / verified boot", RestrictionClass.C,
                "verifiedbootstate=${vbs ?: "unreadable"}, flash.locked=${locked ?: "unreadable"}",
                "n/a", "Unlock policy is set by OnePlus. Unlocking wipes data and is required before custom kernels/root via patched boot. 15R-specific procedure UNVERIFIED.",
                "Reported only."),
            CompatRow("SELinux mode", RestrictionClass.C, "enforce state: ${getprop("ro.boot.selinux") ?: "see adb shell getenforce"}", "n/a",
                "Controls what apps can read (/proc/stat, kgsl, PSI).", "Explains N/A readings."),
        ) + listOf(CompatRow("Kernel / build", RestrictionClass.C,
            "kernel=${System.getProperty("os.version")}, build=${Build.DISPLAY}, sdk=${Build.VERSION.SDK_INT}", "n/a", "Informational.", ""))
    }

    private fun getprop(k: String): String? = try {
        val p = ProcessBuilder("getprop", k).start()
        p.inputStream.bufferedReader().readText().trim().ifEmpty { null }
    } catch (t: Throwable) { null }
}
