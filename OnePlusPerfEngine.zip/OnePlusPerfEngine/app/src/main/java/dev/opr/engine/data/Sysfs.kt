package dev.opr.engine.data

import java.io.File

object NativeSysfs {
    @JvmStatic
    external fun readFiles(paths: Array<String>): Array<String?>
}

/** Read-only sysfs/procfs access. Uses the NDK reader when available, java.io otherwise. */
object Sysfs {
    private val nativeOk: Boolean = try {
        System.loadLibrary("oprdiag"); true
    } catch (t: Throwable) {
        false
    }

    val usingNative: Boolean get() = nativeOk

    fun readAll(paths: List<String>): List<String?> =
        if (nativeOk) NativeSysfs.readFiles(paths.toTypedArray()).toList()
        else paths.map { readJava(it) }

    fun read(path: String): String? = readAll(listOf(path)).first()

    private fun readJava(path: String): String? = try {
        File(path).readText().trim()
    } catch (e: Exception) {
        null
    }

    fun list(dir: String): List<String> = File(dir).list()?.sorted() ?: emptyList()

    fun text(path: String, raw: String?): Reading<String> =
        if (raw != null) Reading.Actual(raw, path)
        else Reading.Inaccessible("unreadable: absent on this kernel or blocked by SELinux for this app")

    fun long(path: String, raw: String?): Reading<Long> {
        val v = raw?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.toLongOrNull()
        return if (v != null) Reading.Actual(v, path)
        else Reading.Inaccessible("unreadable: absent on this kernel or blocked by SELinux for this app")
    }
}
