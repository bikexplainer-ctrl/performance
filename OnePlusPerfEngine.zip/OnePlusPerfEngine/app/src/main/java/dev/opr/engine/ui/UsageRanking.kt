package dev.opr.engine.ui

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process

/** Foreground-time ranking (last hour). This is ACTUAL usage time, not CPU/RAM consumption. */
object UsageRanking {
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    }

    fun top(ctx: Context): List<String> {
        if (!hasAccess(ctx)) return listOf("Usage Access not granted. Settings > Apps > Special app access > Usage access > OPR Perf Engine.")
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        return usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 3_600_000, now)
            .filter { it.totalTimeInForeground > 0 }.sortedByDescending { it.totalTimeInForeground }.take(10)
            .map { "${it.packageName}  fg ${it.totalTimeInForeground / 1000}s" }
            .ifEmpty { listOf("No foreground usage recorded in the last hour.") }
    }
}
