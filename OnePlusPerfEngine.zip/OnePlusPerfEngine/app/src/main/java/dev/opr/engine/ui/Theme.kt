package dev.opr.engine.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import dev.opr.engine.thermal.Level

object C {
    val bg = Color(0xFF0A0D12); val panel = Color(0xFF121821); val line = Color(0xFF1F2933)
    val text = Color(0xFFE6EDF3); val dim = Color(0xFF8B98A5)
    val cyan = Color(0xFF22D3EE); val violet = Color(0xFFA78BFA); val lime = Color(0xFFA3E635); val amber = Color(0xFFFBBF24)
    val green = Color(0xFF34D399); val yellow = Color(0xFFFACC15); val orange = Color(0xFFFB923C); val red = Color(0xFFF87171)
    fun level(l: Level) = when (l) { Level.GREEN -> green; Level.YELLOW -> yellow; Level.ORANGE -> orange; Level.RED -> red }
}

val Mono = FontFamily.Monospace
val Big = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 28.sp, color = C.text)
val Label = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = C.dim, letterSpacing = 1.2.sp)
val Body = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 13.sp, color = C.text)
val MonoSm = TextStyle(fontFamily = Mono, fontSize = 12.sp, color = C.text)

@Composable
fun OprTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(background = C.bg, surface = C.panel, primary = C.cyan, onSurface = C.text, onBackground = C.text),
        content = content,
    )
}
