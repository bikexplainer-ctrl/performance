package dev.opr.engine

import dev.opr.engine.data.*
import dev.opr.engine.game.*
import dev.opr.engine.root.*
import dev.opr.engine.thermal.HealthEvaluator
import org.junit.Assert.*
import org.junit.Test

class CoreLogicTest {
    private fun ts(intervalMs: Double, n: Int) = LongArray(n) { (it * intervalMs * 1e6).toLong() }

    @Test fun perfect120() {
        val s = FrameStatsAnalyzer.analyze(ts(1000.0 / 120, 600), 120)!!
        assertEquals(120.0, s.avgFps, 0.5); assertEquals(0, s.drops); assertEquals(100.0, s.stabilityPct, 0.01)
    }

    @Test fun stutterLowersOnePercentLow() {
        val t = ArrayList<Long>(); var now = 0L
        repeat(1000) { i -> now += ((if (i % 50 == 0) 50.0 else 8.333) * 1e6).toLong(); t += now }
        val s = FrameStatsAnalyzer.analyze(t.toLongArray(), 120)!!
        assertTrue(s.onePctLowFps < 40); assertTrue(s.drops >= 19)
    }

    @Test fun tooFewFramesReturnsNull() = assertNull(FrameStatsAnalyzer.analyze(ts(8.3, 5), 120))

    @Test fun parsesSurfaceFlingerLatency() {
        val txt = "16666666\n0 0 0\n100 1000000 90\n200 17666666 190\n9223372036854775807 9223372036854775807 9223372036854775807\n"
        val p = SurfaceFlingerLatencyParser.parse(txt)!!
        assertEquals(16666666L, p.refreshPeriodNs); assertEquals(2, p.presentNs.size)
    }

    @Test fun slopeOfRisingTemp() {
        val s = (0 until 60).map { it * 1000L to 30f + it * 0.1f }   // +6 °C per minute
        assertEquals(6f, HealthEvaluator.slopeCPerMin(s)!!, 0.05f)
    }

    private fun policy(avail: List<Long>?) = CpuPolicy(
        0, listOf(0), Reading.Actual(300000, "t"), Reading.Actual(3000000, "t"), Reading.Actual(300000, "t"),
        Reading.Actual(3000000, "t"), Reading.Actual(1000000, "t"), Reading.Actual("walt", "t"),
        Reading.Actual(listOf("walt", "performance"), "t"),
        avail?.let { Reading.Actual(it, "t") } ?: Reading.Inaccessible("x"),
    )

    @Test fun tunerRefusesOverclock() {
        val r = RootTuner.plan(policy(listOf(1000000, 3000000)), 3500000, null, null, 0)
        assertTrue(r is PlanResult.Rejected)
    }

    @Test fun tunerRefusesValueOutsideTableAndWhenHot() {
        assertTrue(RootTuner.plan(policy(listOf(1000000, 3000000)), 2000000, null, null, 0) is PlanResult.Rejected)
        assertTrue(RootTuner.plan(policy(listOf(1000000, 3000000)), 1000000, null, null, 3) is PlanResult.Rejected)
    }

    @Test fun tunerAcceptsInTableValueAndRejectsInjectionGovernor() {
        assertTrue(RootTuner.plan(policy(listOf(1000000, 3000000)), 1000000, null, null, 0) is PlanResult.Ok)
        assertTrue(RootTuner.plan(policy(listOf(1000000)), null, null, "walt; reboot", 0) is PlanResult.Rejected)
    }

    @Test fun ceilingReduction() {
        val p = policy(null).copy(scalingMaxKhz = Reading.Actual(2400000, "t"))
        assertEquals(20f, p.ceilingReductionPct!!, 0.01f)
    }
}
